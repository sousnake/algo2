package string;

import java.util.LinkedList;
import java.util.List;

public class RabinKarp {

	public static void main(String[] args) {
		RabinKarp rabinKarp = new RabinKarp();
		System.out.println(rabinKarp.getPatternPosition("IknowhatineedtodoSoyoudonotneedtotellme.".toCharArray(),
				"to".toCharArray()));
	}

	private long prime = 101;

	public List<Integer> getPatternPosition(char text[], char pattern[]) {
		List<Integer> answers = new LinkedList<Integer>();
		int m = pattern.length;
		int n = text.length;
		long patternHash = createHash(pattern, m - 1);
		long textHash = createHash(text, m - 1);

		for (int i = 1; i <= n - m + 1; i++) {
			if (patternHash == textHash && (checkEquality(pattern, 0, m - 1, text, i - 1, i - 2 + m))) {
				answers.add(i - 1);
			}
			if (i < n - m + 1) {
				textHash = recalculateHash(text, textHash, i - 1, i + m - 1);
			}
		}
		return answers;
	}

	private long createHash(char arr[], int end) {
		long hash = 0;
		int i = 0;
		while (i <= end)
			hash += ((long) arr[i] * Math.pow(prime, i++));
		return hash;
	}

	private long recalculateHash(char arr[], long prevHash, int start, int end) {
		long newHash = prevHash - arr[start];
		newHash = newHash / prime;
		newHash += (arr[end] * Math.pow(prime, end - start - 1));
		return newHash;
	}

	private boolean checkEquality(char pattern[], int patternStart, int patternEnd, char text[], int textStart,
			int textEnd) {
		String patternString = new String(pattern, patternStart, patternEnd - patternStart + 1);
		String textString = new String(text, textStart, textEnd - textStart + 1);
		return patternString.equals(textString);
	}
}
