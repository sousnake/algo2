package string;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Stack;

public class Permutation {
	public static Stack<String> perm(String s) {
		Stack<String> s1 = new Stack<String>();
		Stack<String> s2 = new Stack<String>();
		s2.add(s.charAt(0) + "");
		for (int i = 1; i < s.length(); i++) {
			Stack<String> t = s1;
			s1 = s2;
			s2 = t;
			while (!s1.isEmpty()) {
				String temp = s1.pop();
				for (int j = 0; j < temp.length(); j++) {
					String temp2 = temp.substring(0, j) + s.charAt(i) + temp.substring(j);
					s2.add(temp2);
				}
				s2.add(temp + s.charAt(i));
			}

		}
		return s2;
	}

	public static void main(String args[]) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		String line[] = br.readLine().split(" ");
		int arr[] = new int[n];
		for (int i = 0; i < n; i++)
			arr[i] = Integer.parseInt(line[i]);
		int vis[] = new int[n];
		int max = -1;
		for (int i = 0; i < n; i++)
			vis[i] = -1;
		for (int i = 0; i < n; i++) {
			if (vis[i] == -1) {
				int temp = i;
				int prev = -1;
				boolean cycle = true;
				while (vis[temp] == -1) {
					prev++;
					vis[temp] = prev;
					temp = arr[temp];
					if (temp == -1) {
						cycle = false;
						break;
					}
				}
				if (cycle)
					max = Math.max(max, prev + 1 - vis[temp]);
			}
		}
		System.out.println(max);
	}
}
