package practise;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AddOneToNumber {
	public static int minDistance(String a, String b) {
		int[][] res = new int[a.length() + 1][b.length() + 1];
		for (int i = 0; i <= b.length(); i++)
			res[0][i] = i;
		for (int i = 0; i <= a.length(); i++)
			res[i][0] = i;
		for (int i = 1; i <= a.length(); i++) {
			for (int j = 1; j <= b.length(); j++) {
				if (a.charAt(i - 1) == b.charAt(j - 1))
					res[i][j] = res[i - 1][j - 1];
				else
					res[i][j] = Math.min(Math.min(res[i - 1][j], res[i][j - 1]), res[i - 1][j - 1]) + 1;
			}
		}

		for (int i = 0; i <= a.length(); i++) {
			for (int j = 0; j <= b.length(); j++)
				System.out.print(res[i][j] + " ");
			System.out.println();
		}
		return res[a.length()][b.length()];
	}

	public static ListNode subtract(ListNode a) {

		ListNode head = a;
		int len = 0;
		while (head != null) {
			head = head.next;
			len++;
		}
		if (len == 1)
			return a;
		head = a;
		for (int i = 0; i < len / 2 - 1; i++)
			head = head.next;
		if (len % 2 != 0)
			head = head.next;
		ListNode save = head;
		head.next = reverseList(head.next);
		ListNode head2 = a;
		head = head.next;

		while (head2 != null && head != null) {
			head2.val = head.val - head2.val;
			head = head.next;
			head2 = head2.next;
		}
		save.next = reverseList(save.next);
		return a;
	}

	public static ListNode reverseList(ListNode a) {
		ListNode prev = null;
		ListNode next = null;
		ListNode cur = a;
		while (cur != null) {
			next = cur.next;
			cur.next = prev;
			prev = cur;
			cur = next;
		}
		return prev;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// System.out.println(minDistance("Anshuman", "Antihuman"));
		System.out.println(minDistance("aaa", "aa"));
	}

	public static int adjacent(ArrayList<ArrayList<Integer>> a) {
		ArrayList<Integer> one = a.get(0);
		ArrayList<Integer> two = a.get(1);
		int temp[] = new int[one.size()];
		for (int i = 0; i < one.size(); i++) {
			if (i < 2)
				temp[i] = Math.max(one.get(i), two.get(i));
			else if (i == 2) {
				temp[i] = temp[i - 2] + Math.max(one.get(i), two.get(i));
			} else {
				temp[i] = Math.max(temp[i - 2], temp[i - 3]) + Math.max(one.get(i), two.get(i));
			}
		}
		int max = -1;
		for (int i = 0; i < one.size(); i++)
			max = Math.max(max, temp[i]);
		return max;
	}

	public static ArrayList<Integer> dNums(ArrayList<Integer> A, int B) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		ArrayList<Integer> res = new ArrayList<Integer>();
		if (B > A.size())
			return res;
		for (int i = 0; i < B; i++) {
			if (map.containsKey(A.get(i)))
				map.put(A.get(i), map.get(A.get(i)) + 1);
			else
				map.put(A.get(i), 1);
		}
		res.add(map.size());
		for (int i = B; i < A.size(); i++) {
			int temp = A.get(i - B);
			int val = map.remove(temp);
			if (val > 1)
				map.put(temp, val - 1);

			if (map.containsKey(A.get(i)))
				map.put(A.get(i), map.get(A.get(i)) + 1);
			else
				map.put(A.get(i), 1);
			res.add(map.size());
		}
		return res;
	}

	public static int coinchange2(ArrayList<Integer> a, int b) {

		map = new HashMap<>();
		return get(b, a, a.size() - 1);
	}

	static Map<Pair, Integer> map;
	static int mod = 1000007;

	public static int get(int b, ArrayList<Integer> a, int id) {
		if (b == 0)
			return 1;
		if (b < 0)
			return 0;
		if (id < 0)
			return 0;
		Pair p = new Pair(b, id);
		if (map.containsKey(p))
			return map.get(p);
		else {
			int val = (get(b, a, id - 1) + get(b - a.get(id), a, id)) % mod;
			map.put(p, val);
			return val;
		}
	}
}

class Pair {
	public int sum;
	public int id;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + sum;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pair other = (Pair) obj;
		if (id != other.id)
			return false;
		if (sum != other.sum)
			return false;
		return true;
	}

	public Pair(int sum, int id) {
		super();
		this.sum = sum;
		this.id = id;
	}

}

class ListNode {
	public int val;
	public ListNode next;

	ListNode(int x) {
		val = x;
		next = null;
	}

	@Override
	public String toString() {
		return "ListNode [val=" + val + ", next=" + next + "]";
	}

}