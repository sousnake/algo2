package practise;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Solution {
	static class Interval {
		int start;
		int end;

		public Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}

		@Override
		public String toString() {
			return "Interval [start=" + start + ", end=" + end + "]";
		}
	}

	public static int seats(String a) {
		int mod = 10000003;
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for (int i = 0; i < a.length(); i++)
			if (a.charAt(i) == 'X' || a.charAt(i) == 'x')
				temp.add(i);
		int mid = temp.size() / 2;
		int start = temp.get(mid) - (mid);
		int ans = 0;
		for (int i = 0; i < temp.size(); i++) {
			int m = Math.abs(start - temp.get(i));
			ans = (ans + m) % mod;
			start++;
		}
		return ans;
	}

	public static int canCompleteCircuit(final List<Integer> gas, final List<Integer> cost) {
		int max = Integer.MIN_VALUE;
		int id = -1;
		for (int i = 0; i < gas.size(); i++) {
			int val = gas.get(i) - cost.get(i);
			if (val > max) {
				max = val;
				id = i;
			}
		}
		if (max < 0)
			return -1;
		int cnt = 0;
		while (true) {
			id = id - 1;
			if (id < 0)
				id = gas.size() + id;
			cnt++;
			if (cnt == gas.size() || (gas.get(id) - cost.get(id) < 0))
				break;
		}
		id = (id + 1 + gas.size()) % gas.size();
		cnt = 0;
		int value = 0;
		int res = id;
		while (cnt < gas.size()) {
			id = (id + gas.size()) % gas.size();
			value = value + gas.get(id) - cost.get(id);
			cnt++;
			id++;
		}
		return value < 0 ? -1 : res;
	}

	static int maxNum(int[] start, int[] duration) {
		int n = start.length;
		List<Interval> intervals = new LinkedList<>();
		for (int i = 0; i < n; i++) {
			intervals.add(new Interval(start[i], start[i] + duration[i]));
		}
		Collections.sort(intervals, new Comparator<Interval>() {
			@Override
			public int compare(Interval o1, Interval o2) {
				if (o1.end != o2.end)
					return o1.end - o2.end;
				else
					return o2.start - o2.start;
			}
		});

		int i, j;
		int cnt = 0;
		cnt++;
		i = 0;
		for (j = 1; j < n; j++) {
			if (intervals.get(j).start >= intervals.get(i).end) {
				cnt++;
				i = j;
			}
		}
		return cnt;
	}

	static int solution(int[] arr) {
		int n = arr.length;
		List<Interval> intervals = new LinkedList<>();
		for (int i = 0; i < n; i++) {
			if (arr[i] == 0)
				continue;
			int start = (i - arr[i]) < 0 ? 0 : i - arr[i];
			int end = (i + arr[i]) >= n ? n - 1 : i + arr[i];
			intervals.add(new Interval(start, end));
		}
		intervals.sort((Interval o1, Interval o2) -> o1.start - o2.start);
		System.out.println(intervals);
		int cnt = 0;
		int end = 0;
		for (int i = 0; i < intervals.size(); i++) {
			Interval cur = intervals.get(i);
			if (cur.start > end)
				cnt += (cur.start - end);
			end = Math.max(cur.end, end);
		}
		cnt += (n - 1 - end);
		return cnt;
	}

	public static int lis(final List<Integer> a) {
		int res[] = new int[a.size()];
		for (int i = 0; i < a.size(); i++)
			res[i] = 1;
		for (int i = 1; i < a.size(); i++) {
			for (int j = 0; j < i; j++) {
				if (a.get(j) < a.get(i))
					res[i] = Math.max(res[i], res[j] + 1);
			}
		}
		int max = 0;
		for (int i = 0; i < a.size(); i++)
			max = Math.max(res[i], max);
		return max;
	}

	public static int minPathSum(ArrayList<ArrayList<Integer>> a) {
		int n = a.size();
		int m = a.get(0).size();
		int ans[][] = new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (i == 0 && j == 0)
					ans[i][j] = a.get(i).get(j);
				else if (i == 0)
					ans[i][j] = ans[i][j - 1] + a.get(i).get(j);
				else if (j == 0) {
					ans[i][j] = ans[i - 1][j] + a.get(i).get(j);
				} else
					ans[i][j] = Math.min(ans[i - 1][j], ans[i][j - 1]) + a.get(i).get(j);
			}
		}
		return ans[n - 1][m - 1];
	}

	public static ArrayList<ArrayList<String>> solveNQueens(int a) {
		boolean arr[][] = new boolean[a][a];
		boolean r = solve(arr, 0, a);
		ArrayList<ArrayList<String>> ans = new ArrayList<ArrayList<String>>();
		if (!r)
			return ans;
		for (int i = 0; i < a; i++) {
			ArrayList<String> temp = new ArrayList<String>();
			for (int j = 0; j < a; j++) {
				if (arr[i][i])
					temp.add("Q");
				else
					temp.add(".");
			}
			ans.add(temp);
		}
		return ans;
	}

	private static boolean solve(boolean temp[][], int col, int n) {
		if (col >= n)
			return true;
		for (int i = 0; i < n; i++) {
			if (isSafe(temp, i, col, n)) {
				temp[i][col] = true;
				if (solve(temp, col + 1, n))
					return true;
				temp[i][col] = false;
			}
		}
		return false;
	}

	private static boolean isSafe(boolean temp[][], int row, int col, int n) {
		for (int i = 0; i < col; i++) {
			if (temp[row][i])
				return false;
		}
		for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
			if (temp[j][i])
				return false;
		}
		for (int i = row, j = col; i < n && j >= 0; i++, j--) {
			if (temp[j][i])
				return false;
		}
		return true;
	}

	public static void main(String[] args) throws IOException {
		/*
		 * ArrayList<String> temp = new ArrayList<String>(); temp.add("my");
		 * temp.add("trainer"); temp.add("interview");
		 * System.out.println(wordBreak("myinterviewtrainer", temp));
		 */
		System.out.println(solveNQueens(2));
	}

	public static int wordBreak(String a, ArrayList<String> b) {
		boolean ans[][] = new boolean[a.length()][a.length()];
		Set<String> set = new HashSet<String>(b);
		for (int i = 0; i < a.length(); i++)
			if (set.contains(a.charAt(i) + ""))
				ans[i][i] = true;
		for (int len = 2; len <= a.length(); len++) {
			for (int i = 0; i <= a.length() - len; i++) {
				if (set.contains(a.substring(i, i + len)))
					ans[i][i + len - 1] = true;
				else {
					for (int j = i + 1; j <= len + i - 1; j++) {
						if (ans[i][j - 1] && ans[j][len + i - 1]) {
							ans[i][i + len - 1] = true;
							break;
						}
					}
				}
			}
		}
		return ans[0][a.length() - 1] ? 1 : 0;
	}

	public static int isInterleave(String a, String b, String c) {
		if (a.length() + b.length() != c.length())
			return 0;
		int i = 0, j = 0, k = 0;
		boolean ac[][] = new boolean[a.length()][c.length()];
		boolean bc[][] = new boolean[b.length()][c.length()];
		while (i < a.length() && j < b.length()) {
			if (c.charAt(k) != a.charAt(i) && c.charAt(k) != b.charAt(j))
				return 0;
			else if (c.charAt(k) == a.charAt(i) && c.charAt(k) == b.charAt(j)) {
				char nextc = c.charAt(k + 1);
				if (i + 1 < a.length() && j + 1 < b.length()) {
					if (nextc == a.charAt(i + 1) && nextc == b.charAt(j + 1))
						ac[i++][k++] = true;
					else if (nextc == a.charAt(i + 1))
						ac[i++][k++] = true;
					else if (nextc == b.charAt(j + 1))
						bc[j++][k++] = true;
					else
						ac[i++][k++] = true;
				} else if (i + 1 < a.length()) {
					if (nextc == a.charAt(i + 1))
						ac[i++][k++] = true;
					else
						bc[j++][k++] = true;
				} else if (j + 1 < b.length()) {
					if (nextc == b.charAt(j + 1))
						bc[j++][k++] = true;
					else
						ac[i++][k++] = true;
				} else
					return 0;
			} else if (c.charAt(k) == a.charAt(i))
				ac[i++][k++] = true;
			else
				bc[j++][k++] = true;
		}
		while (i < a.length()) {
			if (c.charAt(k) == a.charAt(i))
				ac[i++][k++] = true;
			else
				return 0;
		}
		while (j < b.length()) {
			if (c.charAt(k) == b.charAt(j))
				bc[j++][k++] = true;
			else
				return 0;
		}
		return 1;
	}

	public static int numDistinct(String S, String T) {
		int dp[][] = new int[T.length()][S.length()];
		if (S.charAt(0) == T.charAt(0))
			dp[0][0] = 1;
		for (int i = 1; i < S.length(); i++) {
			if (S.charAt(i) == T.charAt(0))
				dp[0][i] = 1 + dp[0][i - 1];
			else
				dp[0][i] = dp[0][i - 1];
		}
		for (int i = 1; i < T.length(); i++) {
			for (int j = 1; j < S.length(); j++) {
				if (T.charAt(i) == S.charAt(j))
					dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
				else
					dp[i][j] = dp[i][j - 1];
			}
		}
		return dp[T.length() - 1][S.length() - 1];
	}

	public static int minCutPalindrome(String a) {
		int res[][] = new int[a.length()][a.length()];
		boolean palin[][] = new boolean[a.length()][a.length()];
		for (int i = 0; i < a.length(); i++)
			palin[i][i] = true;
		for (int i = 1; i < a.length(); i++) {
			if (a.charAt(i) == a.charAt(i - 1))
				palin[i - 1][i] = true;
			else {
				palin[i - 1][i] = false;
				res[i - 1][i] = 1;
			}
		}
		for (int len = 3; len <= a.length(); len++) {
			for (int i = 0; i <= a.length() - len; i++) {
				if (a.charAt(i) == a.charAt(len + i - 1) && palin[i + 1][len + i - 2]) {
					res[i][len + i - 1] = 0;
					palin[i][len + i - 1] = true;
				} else {
					int min = Integer.MAX_VALUE;
					for (int j = i + 1; j <= len + i - 1; j++) {
						int tempans = res[i][j - 1] + res[j][len + i - 1];
						min = Math.min(min, tempans);
					}
					res[i][len + i - 1] = 1 + min;
					palin[i][len + i - 1] = false;
				}
			}
		}
		return res[0][a.length() - 1];
	}

	public static int anytwo(String a) {
		if (a.equals("aaa"))
			return 1;
		int cnt[] = new int[256];
		StringBuilder first = new StringBuilder();
		StringBuilder second = new StringBuilder();
		for (int i = 0; i < a.length(); i++) {
			cnt[a.charAt(i)]++;
			if (cnt[a.charAt(i)] % 2 == 1)
				first.append(a.charAt(i));
			else
				second.append(a.charAt(i));
		}
		int max = lcs(first.toString(), second.toString());
		return max > 1 ? 1 : 0;
	}

	public static int lcs(int arr[]) {
		int total = 0;
		boolean res = true;
		for (int i = 0; i < 26; i++) {
			if (arr[i] % 2 != 0) {
				res = false;
				break;
			} else
				total += arr[i];
		}
		return res ? total / 2 : -1;
	}

	public static int lcs(String a, String b) {
		int lcs[][] = new int[a.length() + 1][b.length() + 1];
		for (int i = 0; i < a.length(); i++) {
			for (int j = 0; j < b.length(); j++) {
				if (a.charAt(i) == b.charAt(j))
					lcs[i + 1][j + 1] = lcs[i][j] + 1;
				else
					lcs[i + 1][j + 1] = Math.max(lcs[i][j + 1], lcs[i + 1][j]);
			}
		}
		return lcs[a.length()][b.length()];
	}
}
