package stacks;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class SimplifyDirectoryPath {
	public static String simplifyPath(String a) {
		Stack<String> st = new Stack<String>();
		StringBuilder sb = new StringBuilder();
		for (int i = 1; i < a.length();) {
			int end = i;
			if (end >= a.length())
				break;
			char temp = a.charAt(end);
			while (temp != '/') {
				end++;
				if (end >= a.length())
					break;
				temp = a.charAt(end);
			}
			String tempS = a.substring(i, end);
			i = end + 1;
			if (tempS.equals("..")) {
				if (!st.isEmpty())
					st.pop();
			} else if (tempS.equals(".")) {

			} else
				st.push(tempS);
		}
		for (int i = 0; i < st.size(); i++) {
			if (!st.get(i).equals(""))
				sb.append("/" + st.get(i));
		}
		if (st.size() == 0)
			sb.append("/");
		return sb.toString();
	}

	public static void main(String[] args) {
		/*
		 * System.out.println(simplifyPath("/a1/./b2/../c3"));
		 * System.out.println(simplifyPath("/home/"));
		 * System.out.println(simplifyPath("/"));
		 * System.out.println(simplifyPath("/../"));
		 * System.out.println(simplifyPath("/home//foo/"));
		 */
		TreeLinkNode root = new TreeLinkNode(1);
		root.left = new TreeLinkNode(2);
		root.right = new TreeLinkNode(3);
		root.right.left = new TreeLinkNode(4);
		root.right.left.right = new TreeLinkNode(5);
		Queue<TreeLinkNode> f = new LinkedList<>();
		Queue<TreeLinkNode> s = new LinkedList<>();
		f.add(root);
		while (!s.isEmpty() || !f.isEmpty()) {
			while (!f.isEmpty()) {
				TreeLinkNode temp = f.poll();
				temp.next = f.isEmpty() ? null : f.peek();
				if (temp.left != null)
					s.add(temp.left);
				if (temp.right != null)
					s.add(temp.right);
			}
			Queue<TreeLinkNode> te = f;
			f = s;
			s = te;
		}
		System.out.println(root);
	}
}

class TreeLinkNode {
	int val;
	TreeLinkNode left, right, next;

	TreeLinkNode(int x) {
		val = x;
	}

	@Override
	public String toString() {
		return "TreeLinkNode [val=" + val + ", left=" + left + ", right=" + right + ", next=" + next + "]";
	}

}
