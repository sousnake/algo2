package stacks;

import java.util.Stack;

public class MinStack {
	private Stack<Element> st = new Stack<Element>();

	public void push(int x) {
		if (st.isEmpty())
			st.push(new Element(x, x));
		else {
			Element temp = st.peek();
			st.push(new Element(x, Math.min(x, temp.min)));
		}
	}

	public void pop() {
		if (!st.isEmpty())
			st.pop();
	}

	public int top() {
		if (!st.isEmpty())
			return st.peek().val;
		else
			return -1;
	}

	public int getMin() {
		if (!st.isEmpty())
			return st.peek().min;
		else
			return -1;
	}

}

class Element {
	int val;
	int min;

	public Element(int val, int min) {
		this.val = val;
		this.min = min;
	}
}