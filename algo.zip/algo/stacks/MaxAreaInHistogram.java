package stacks;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class MaxAreaInHistogram {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine());
		for (int i = 0; i < t; i++) {
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int arr[] = new int[n];
			for (int j = 0; j < n; j++)
				arr[j] = Integer.parseInt(s[j]);
			System.out.println(getMaxArea(arr));
		}

	}

	public static int getMaxArea(int arr[]) {
		Stack<Integer> s = new Stack<Integer>();
		int maxArea = -1;
		int i = 0;
		for (i = 0; i < arr.length; i++) {
			if (s.isEmpty() || arr[i] >= arr[s.peek()])
				s.add(i);
			else {
				while (!s.isEmpty() && arr[s.peek()] > arr[i]) {
					int pop = s.pop();
					int curArea = 0;
					if (s.isEmpty())
						curArea = i * arr[pop];
					else
						curArea = (i - 1 - s.peek()) * arr[pop];
					maxArea = Math.max(maxArea, curArea);
				}
				s.add(i);
			}
		}
		while (!s.isEmpty()) {
			int pop = s.pop();
			int curArea = 0;
			if (s.isEmpty())
				curArea = i * arr[pop];
			else
				curArea = (i - 1 - s.peek()) * arr[pop];
			maxArea = Math.max(maxArea, curArea);
		}
		return maxArea;
	}
}
